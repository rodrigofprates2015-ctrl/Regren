import { Link } from 'wouter';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  ArrowRight, 
  Cog, 
  Wrench, 
  Factory, 
  Cpu, 
  Gauge, 
  Settings2,
  Hammer,
  Layers,
  PenTool,
  CheckCircle2
} from 'lucide-react';

const services = [
  {
    icon: PenTool,
    title: 'Projetos 3D',
    description: 'Desenvolvimento de projetos em 3D para customização de equipamentos industriais conforme necessidade específica do cliente.',
    features: ['Modelagem 3D avançada', 'Renderização fotorrealista', 'Documentação técnica completa']
  },
  {
    icon: Wrench,
    title: 'Manutenção Industrial',
    description: 'Serviços completos de manutenção preventiva e corretiva para garantir a operação contínua dos seus equipamentos.',
    features: ['Manutenção preventiva', 'Manutenção corretiva', 'Paradas programadas']
  },
  {
    icon: Cog,
    title: 'Usinagem',
    description: 'Serviços de usinagem de precisão com equipamentos modernos e mão de obra especializada.',
    features: ['Tornos CNC', 'Fresadoras', 'Retíficas']
  },
  {
    icon: Factory,
    title: 'Caldeiraria',
    description: 'Fabricação e manutenção de estruturas metálicas, tanques, tubulações e equipamentos em geral.',
    features: ['Estruturas metálicas', 'Tanques e reservatórios', 'Tubulações industriais']
  },
  {
    icon: Hammer,
    title: 'Montagem Industrial',
    description: 'Montagem e desmontagem de equipamentos industriais com equipe técnica qualificada.',
    features: ['Montagem de linhas', 'Instalação de equipamentos', 'Alinhamento de precisão']
  },
  {
    icon: Cpu,
    title: 'Automação',
    description: 'Soluções de automação industrial para otimização de processos e aumento da produtividade.',
    features: ['CLPs e IHMs', 'Sensores e atuadores', 'Integração de sistemas']
  },
  {
    icon: Gauge,
    title: 'Instrumentação',
    description: 'Calibração, instalação e manutenção de instrumentos de medição e controle industrial.',
    features: ['Calibração', 'Instalação', 'Manutenção de instrumentos']
  },
  {
    icon: Settings2,
    title: 'Retrofitting',
    description: 'Modernização de máquinas e equipamentos antigos para melhorar performance e eficiência.',
    features: ['Atualização tecnológica', 'Aumento de vida útil', 'Redução de custos']
  },
  {
    icon: Layers,
    title: 'Engenharia de Projetos',
    description: 'Desenvolvimento de soluções personalizadas de engenharia para desafios específicos da sua operação.',
    features: ['Análise de viabilidade', 'Projetos sob medida', 'Acompanhamento técnico']
  }
];

export default function Servicos() {
  return (
    <Layout>
      <section className="bg-industrial bg-noise py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="font-display font-bold text-4xl md:text-5xl text-white mb-6 animate-slide-up">
              Nossos <span className="text-secondary">Serviços</span>
            </h1>
            <p className="text-gray-300 text-lg md:text-xl leading-relaxed animate-slide-up" style={{ animationDelay: '0.1s' }}>
              Oferecemos soluções completas de engenharia e manutenção industrial, com mais de 20 anos de experiência no mercado.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card 
                key={service.title}
                className="group border shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden"
                data-testid={`card-service-${index}`}
              >
                <CardContent className="p-6">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary transition-all duration-300">
                    <service.icon className="w-7 h-7 text-primary group-hover:text-white transition-colors" />
                  </div>
                  
                  <h3 className="font-display font-bold text-xl mb-3 group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  
                  <p className="text-muted-foreground mb-4 leading-relaxed text-sm">
                    {service.description}
                  </p>
                  
                  <ul className="space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 text-secondary shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="font-display font-bold text-2xl md:text-3xl mb-3">
                Precisa de um serviço específico?
              </h2>
              <p className="text-muted-foreground">
                Entre em contato conosco para discutir sua necessidade e receber um orçamento personalizado.
              </p>
            </div>
            <Link href="/orcamento">
              <Button size="lg" className="bg-secondary hover:bg-secondary/90 gap-2 shrink-0" data-testid="button-orcamento-servicos">
                Solicitar Orçamento
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}
